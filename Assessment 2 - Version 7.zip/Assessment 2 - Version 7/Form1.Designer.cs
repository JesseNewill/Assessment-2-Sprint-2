﻿
namespace Assessment_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ButtonAdd = new System.Windows.Forms.Button();
            this.ButtonEdit = new System.Windows.Forms.Button();
            this.ButtonDelete = new System.Windows.Forms.Button();
            this.ButtonSort = new System.Windows.Forms.Button();
            this.ButtonSearch = new System.Windows.Forms.Button();
            this.ButtonTest = new System.Windows.Forms.Button();
            this.StatusStrip = new System.Windows.Forms.StatusStrip();
            this.ToolStripStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.TextBox = new System.Windows.Forms.TextBox();
            this.ListBox = new System.Windows.Forms.ListBox();
            this.ButtonSequentialSearch = new System.Windows.Forms.Button();
            this.ButtonMidExtreme = new System.Windows.Forms.Button();
            this.ButtonMode = new System.Windows.Forms.Button();
            this.ButtonAverage = new System.Windows.Forms.Button();
            this.ButtonRange = new System.Windows.Forms.Button();
            this.TextBoxMidExtreme = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.TextBoxMode = new System.Windows.Forms.TextBox();
            this.TextBoxAverage = new System.Windows.Forms.TextBox();
            this.TextBoxRange = new System.Windows.Forms.TextBox();
            this.StatusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // ButtonAdd
            // 
            this.ButtonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonAdd.ForeColor = System.Drawing.SystemColors.Window;
            this.ButtonAdd.Location = new System.Drawing.Point(210, 37);
            this.ButtonAdd.Name = "ButtonAdd";
            this.ButtonAdd.Size = new System.Drawing.Size(208, 23);
            this.ButtonAdd.TabIndex = 0;
            this.ButtonAdd.Text = "Add";
            this.ButtonAdd.UseVisualStyleBackColor = false;
            this.ButtonAdd.Click += new System.EventHandler(this.ButtonAdd_Click);
            // 
            // ButtonEdit
            // 
            this.ButtonEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonEdit.ForeColor = System.Drawing.Color.White;
            this.ButtonEdit.Location = new System.Drawing.Point(210, 63);
            this.ButtonEdit.Name = "ButtonEdit";
            this.ButtonEdit.Size = new System.Drawing.Size(208, 23);
            this.ButtonEdit.TabIndex = 1;
            this.ButtonEdit.Text = "Edit";
            this.ButtonEdit.UseVisualStyleBackColor = false;
            this.ButtonEdit.Click += new System.EventHandler(this.ButtonEdit_Click);
            // 
            // ButtonDelete
            // 
            this.ButtonDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonDelete.ForeColor = System.Drawing.Color.White;
            this.ButtonDelete.Location = new System.Drawing.Point(210, 92);
            this.ButtonDelete.Name = "ButtonDelete";
            this.ButtonDelete.Size = new System.Drawing.Size(208, 23);
            this.ButtonDelete.TabIndex = 2;
            this.ButtonDelete.Text = "Delete";
            this.ButtonDelete.UseVisualStyleBackColor = false;
            this.ButtonDelete.Click += new System.EventHandler(this.ButtonDelete_Click);
            // 
            // ButtonSort
            // 
            this.ButtonSort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonSort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonSort.ForeColor = System.Drawing.Color.White;
            this.ButtonSort.Location = new System.Drawing.Point(210, 121);
            this.ButtonSort.Name = "ButtonSort";
            this.ButtonSort.Size = new System.Drawing.Size(208, 23);
            this.ButtonSort.TabIndex = 3;
            this.ButtonSort.Text = "Sort";
            this.ButtonSort.UseVisualStyleBackColor = false;
            this.ButtonSort.Click += new System.EventHandler(this.ButtonSort_Click);
            // 
            // ButtonSearch
            // 
            this.ButtonSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonSearch.ForeColor = System.Drawing.Color.White;
            this.ButtonSearch.Location = new System.Drawing.Point(210, 213);
            this.ButtonSearch.Name = "ButtonSearch";
            this.ButtonSearch.Size = new System.Drawing.Size(208, 23);
            this.ButtonSearch.TabIndex = 4;
            this.ButtonSearch.Text = "Binary Search";
            this.ButtonSearch.UseVisualStyleBackColor = false;
            this.ButtonSearch.Click += new System.EventHandler(this.ButtonSearch_Click);
            // 
            // ButtonTest
            // 
            this.ButtonTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonTest.ForeColor = System.Drawing.Color.White;
            this.ButtonTest.Location = new System.Drawing.Point(46, 425);
            this.ButtonTest.Name = "ButtonTest";
            this.ButtonTest.Size = new System.Drawing.Size(120, 23);
            this.ButtonTest.TabIndex = 5;
            this.ButtonTest.Text = "Auto Fill";
            this.ButtonTest.UseVisualStyleBackColor = false;
            this.ButtonTest.Click += new System.EventHandler(this.ButtonTest_Click);
            // 
            // StatusStrip
            // 
            this.StatusStrip.BackColor = System.Drawing.Color.White;
            this.StatusStrip.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.StatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripStatus});
            this.StatusStrip.Location = new System.Drawing.Point(0, 496);
            this.StatusStrip.Name = "StatusStrip";
            this.StatusStrip.Size = new System.Drawing.Size(448, 22);
            this.StatusStrip.TabIndex = 6;
            this.StatusStrip.Text = "statusStrip1";
            // 
            // ToolStripStatus
            // 
            this.ToolStripStatus.BackColor = System.Drawing.Color.Transparent;
            this.ToolStripStatus.Name = "ToolStripStatus";
            this.ToolStripStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // TextBox
            // 
            this.TextBox.Location = new System.Drawing.Point(46, 37);
            this.TextBox.Name = "TextBox";
            this.TextBox.Size = new System.Drawing.Size(120, 20);
            this.TextBox.TabIndex = 7;
            this.TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_KeyPress);
            // 
            // ListBox
            // 
            this.ListBox.FormattingEnabled = true;
            this.ListBox.Location = new System.Drawing.Point(46, 85);
            this.ListBox.Name = "ListBox";
            this.ListBox.Size = new System.Drawing.Size(120, 329);
            this.ListBox.TabIndex = 8;
            this.ListBox.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged);
            // 
            // ButtonSequentialSearch
            // 
            this.ButtonSequentialSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonSequentialSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonSequentialSearch.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonSequentialSearch.Location = new System.Drawing.Point(210, 242);
            this.ButtonSequentialSearch.Name = "ButtonSequentialSearch";
            this.ButtonSequentialSearch.Size = new System.Drawing.Size(208, 23);
            this.ButtonSequentialSearch.TabIndex = 9;
            this.ButtonSequentialSearch.Text = "Sequential Search";
            this.ButtonSequentialSearch.UseVisualStyleBackColor = false;
            this.ButtonSequentialSearch.Click += new System.EventHandler(this.ButtonSequentialSearch_Click);
            // 
            // ButtonMidExtreme
            // 
            this.ButtonMidExtreme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonMidExtreme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonMidExtreme.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonMidExtreme.Location = new System.Drawing.Point(210, 338);
            this.ButtonMidExtreme.Name = "ButtonMidExtreme";
            this.ButtonMidExtreme.Size = new System.Drawing.Size(75, 23);
            this.ButtonMidExtreme.TabIndex = 10;
            this.ButtonMidExtreme.Text = "Mid-Extreme";
            this.ButtonMidExtreme.UseVisualStyleBackColor = false;
            this.ButtonMidExtreme.Click += new System.EventHandler(this.ButtonMidExtreme_Click);
            // 
            // ButtonMode
            // 
            this.ButtonMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonMode.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonMode.Location = new System.Drawing.Point(210, 367);
            this.ButtonMode.Name = "ButtonMode";
            this.ButtonMode.Size = new System.Drawing.Size(75, 23);
            this.ButtonMode.TabIndex = 11;
            this.ButtonMode.Text = "Mode";
            this.ButtonMode.UseVisualStyleBackColor = false;
            this.ButtonMode.Click += new System.EventHandler(this.ButtonMode_Click);
            // 
            // ButtonAverage
            // 
            this.ButtonAverage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonAverage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonAverage.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonAverage.Location = new System.Drawing.Point(210, 396);
            this.ButtonAverage.Name = "ButtonAverage";
            this.ButtonAverage.Size = new System.Drawing.Size(75, 23);
            this.ButtonAverage.TabIndex = 12;
            this.ButtonAverage.Text = "Average";
            this.ButtonAverage.UseVisualStyleBackColor = false;
            this.ButtonAverage.Click += new System.EventHandler(this.ButtonAverage_Click);
            // 
            // ButtonRange
            // 
            this.ButtonRange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(12)))), ((int)(((byte)(102)))));
            this.ButtonRange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonRange.ForeColor = System.Drawing.SystemColors.Control;
            this.ButtonRange.Location = new System.Drawing.Point(210, 425);
            this.ButtonRange.Name = "ButtonRange";
            this.ButtonRange.Size = new System.Drawing.Size(75, 23);
            this.ButtonRange.TabIndex = 13;
            this.ButtonRange.Text = "Range";
            this.ButtonRange.UseVisualStyleBackColor = false;
            this.ButtonRange.Click += new System.EventHandler(this.ButtonRange_Click);
            // 
            // TextBoxMidExtreme
            // 
            this.TextBoxMidExtreme.Location = new System.Drawing.Point(291, 340);
            this.TextBoxMidExtreme.Name = "TextBoxMidExtreme";
            this.TextBoxMidExtreme.ReadOnly = true;
            this.TextBoxMidExtreme.Size = new System.Drawing.Size(127, 20);
            this.TextBoxMidExtreme.TabIndex = 14;
            // 
            // TextBoxMode
            // 
            this.TextBoxMode.Location = new System.Drawing.Point(291, 370);
            this.TextBoxMode.Name = "TextBoxMode";
            this.TextBoxMode.ReadOnly = true;
            this.TextBoxMode.Size = new System.Drawing.Size(127, 20);
            this.TextBoxMode.TabIndex = 15;
            // 
            // TextBoxAverage
            // 
            this.TextBoxAverage.Location = new System.Drawing.Point(291, 399);
            this.TextBoxAverage.Name = "TextBoxAverage";
            this.TextBoxAverage.ReadOnly = true;
            this.TextBoxAverage.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAverage.TabIndex = 16;
            // 
            // TextBoxRange
            // 
            this.TextBoxRange.Location = new System.Drawing.Point(291, 428);
            this.TextBoxRange.Name = "TextBoxRange";
            this.TextBoxRange.ReadOnly = true;
            this.TextBoxRange.Size = new System.Drawing.Size(127, 20);
            this.TextBoxRange.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(10)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(448, 518);
            this.Controls.Add(this.TextBoxRange);
            this.Controls.Add(this.TextBoxAverage);
            this.Controls.Add(this.TextBoxMode);
            this.Controls.Add(this.TextBoxMidExtreme);
            this.Controls.Add(this.ButtonRange);
            this.Controls.Add(this.ButtonAverage);
            this.Controls.Add(this.ButtonMode);
            this.Controls.Add(this.ButtonMidExtreme);
            this.Controls.Add(this.ButtonSequentialSearch);
            this.Controls.Add(this.ListBox);
            this.Controls.Add(this.TextBox);
            this.Controls.Add(this.StatusStrip);
            this.Controls.Add(this.ButtonTest);
            this.Controls.Add(this.ButtonSearch);
            this.Controls.Add(this.ButtonSort);
            this.Controls.Add(this.ButtonDelete);
            this.Controls.Add(this.ButtonEdit);
            this.Controls.Add(this.ButtonAdd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Astronomical Processing";
            this.StatusStrip.ResumeLayout(false);
            this.StatusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonAdd;
        private System.Windows.Forms.Button ButtonEdit;
        private System.Windows.Forms.Button ButtonDelete;
        private System.Windows.Forms.Button ButtonSort;
        private System.Windows.Forms.Button ButtonSearch;
        private System.Windows.Forms.Button ButtonTest;
        private System.Windows.Forms.StatusStrip StatusStrip;
        private System.Windows.Forms.TextBox TextBox;
        private System.Windows.Forms.ListBox ListBox;
        private System.Windows.Forms.ToolStripStatusLabel ToolStripStatus;
        private System.Windows.Forms.Button ButtonSequentialSearch;
        private System.Windows.Forms.Button ButtonMidExtreme;
        private System.Windows.Forms.Button ButtonMode;
        private System.Windows.Forms.Button ButtonAverage;
        private System.Windows.Forms.Button ButtonRange;
        private System.Windows.Forms.TextBox TextBoxMidExtreme;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox TextBoxMode;
        private System.Windows.Forms.TextBox TextBoxAverage;
        private System.Windows.Forms.TextBox TextBoxRange;
    }
}

