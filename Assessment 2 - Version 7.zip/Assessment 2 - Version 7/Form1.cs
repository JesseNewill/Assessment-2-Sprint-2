﻿using System;

using System.Windows.Forms;
//Alexis and Jesse
//Assessment 2 - Sprint 2
//Version 6
//13/10/2021
//Astronomical Processing program
//Program that records hourly neutrino interactions input by the user
namespace Assessment_2
{
    public partial class Form1 : Form
    {
        //S1: CR - The name of the application should be Astronomical Processing
        public Form1()
        {
            InitializeComponent();
            //S2: CR All GUI components have detailed tool tips
            //Tool Tips for the buttons
            toolTip1.SetToolTip(ButtonAdd, "This button will Add data to the list.");
            toolTip1.SetToolTip(ButtonEdit, "This button will Edit selected data in the list.");
            toolTip1.SetToolTip(ButtonDelete, "This button will Delete data in the list.");
            toolTip1.SetToolTip(ButtonSort, "This button will Sort the data in the list.");
            toolTip1.SetToolTip(ButtonSearch, "This button will use a Binary search to search through the data in the list.");
            toolTip1.SetToolTip(ButtonSequentialSearch, "This button will use a Sequential Search to" +
                " search through the data in the list.");
            toolTip1.SetToolTip(ButtonMidExtreme, "This button will calculate the Mid-Extreme of the data in the list.");
            toolTip1.SetToolTip(ButtonMode, "This button will calculate the Mode of the data in the list.");
            toolTip1.SetToolTip(ButtonAverage, "This button will calculate the Average of the data in the list.");
            toolTip1.SetToolTip(ButtonRange, "This button will calculate the Range of the data in the list.");
            toolTip1.SetToolTip(ButtonTest, "This button will Auto Fill the list with random data.");
        }
        //S1: PR - The array has 24 elements to reflect the number of hours per day
        static int max = 24;
        //S1: CR - All data is stored as integers in an array
        //S1: PR - The array is of type integer
        //New array of integers called Astronomical_Processing with max of 24 items
        int[] Astronomical_Processing = new int[max];
        int nextEmptySpot = 0;

        //Displays the items in the array in the listbox field 
        private void DisplayTasks()
        {
            ListBox.Items.Clear();
            for (int x = 0; x < nextEmptySpot; x++)
            {
                ListBox.Items.Add(Astronomical_Processing[x]);
            }
        }
        #region AddEditDelete
        //S1: PR The program must be able to add, edit and delete values
        //S1: CR There is an input field (text box) so data can be deleted, added and edited
        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                if (ListBox.Items.Count < max)
                {
                    //Integer data input by user will be assigned to the next spot in the 
                    //array and displayed in the listbox field when the add button is selected
                    try
                    {
                        Astronomical_Processing[nextEmptySpot] = int.Parse(TextBox.Text);
                        nextEmptySpot++;
                        DisplayTasks();
                        TextBox.Clear();
                        TextBox.Select();
                        ToolStripStatus.Text = "The data has been added.";
                    }
                    catch
                    //Where data input is not integer type, the user will be prompted to input
                    //the correct data type when the add button is selected
                    {
                        MessageBox.Show("Please input a whole number.");
                        ToolStripStatus.Text = "";

                    }
                }
                else
                //When the add button is used and the maximum number of items in the array 
                //has been filled, the user will be notified
                {
                    MessageBox.Show("The maximum number of items has been reached.");
                    ToolStripStatus.Text = "";
                }

            }
            else
            //S1: PR The program must generate an error message if the text box is empty
            //S2: PR The program must generate an error message if the text box is empty
            //Where the add button has been selected and no data input into the text box
            //the user will be prompted to input an integer
            {
                MessageBox.Show("The text box is empty. Please input a whole number.");
                ToolStripStatus.Text = "";
            }
        }
        //S1: PR The program must be able to add, edit and delete values
        //S1: CR There is an input field (text box) so data can be deleted, added and edited
        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            //Where the user has not selected an item in the array to edit, a message will 
            //appear prompting the user to select an item
            if (ListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the item you wish to edit in the listbox.");
            }
            //Data input by the user will replace the item selected in the array (displayed in the 
            //listbox) when the edit button is selected
            else if (!string.IsNullOrEmpty(TextBox.Text))
            {

                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                Astronomical_Processing[taskIndex] = int.Parse(TextBox.Text);
                ToolStripStatus.Text = "The item has been edited.";
                
            }
            //When no replacement data is included in the text box and an item in the array is
            //selected, when the edit button is selected, the user will be prompted to include the
            //replacement data in the text box
            else
            {
                MessageBox.Show("Please select an item from the list to edit and include the replacement input in the text box.");
                ToolStripStatus.Text = "";
            }
            DisplayTasks();
            TextBox.Clear();

        }
        //S1: PR The program must be able to add, edit and delete values
        //S1: CR There is an input field (text box) so data can be deleted, added and edited
        //Item selected by the user in the array (displayed in the listbox) will be deleted when the
        //delete button is selected
        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (ListBox.SelectedIndex != -1)
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                DialogResult DeleteTask = MessageBox.Show("Are you sure you want to delete this data?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (DeleteTask == DialogResult.Yes)
                {
                    Astronomical_Processing[taskIndex] = Astronomical_Processing[nextEmptySpot - 1];
                    nextEmptySpot--;
                    ToolStripStatus.Text = "The item has been deleted.";
                    DisplayTasks();
                    TextBox.Clear();
                }
                //When the user selects 'No' a message box will appear to confirm the item has
                //not been deleted
                else
                {
                    MessageBox.Show("The item has NOT been deleted.");
                    ToolStripStatus.Text = "";
                }
                //When the user selects the delete button without selecting an item to be deleted,
                //a message box will appear, prompting them to select an item
            }
            else
            {
                MessageBox.Show("Please select an item from the list to delete.");
                ToolStripStatus.Text = "";
            }

        }
        #endregion

        #region Sort
        //S1: PR The sort method must be coded using the bubble sort algorithm
        //S1: CR There are buttons that can search and sort the data
        //Bubble sort
        private void ButtonSort_Click(object sender, EventArgs e)
        {
            //Declaring integer I as 0 - this is the index value in the array that the sort will commence from
            //When I is less than the length of the array, I will increases by 1
            for (int i = 0; i < nextEmptySpot; i++)
            {
                //Declaring integer J as I + 1
                //When J is less than the length of the array, J will increase by 1 
                for (int j = i + 1; j < nextEmptySpot; j++)
                {
                    //If I is greater than J
                    if (Astronomical_Processing[i] > Astronomical_Processing[j])
                    {
                        //Declaring integer 'temp' to be the same value as array index I
                        int temp = Astronomical_Processing[i];
                        //Setting the value of array index J to array index I
                        Astronomical_Processing[i] = Astronomical_Processing[j];
                        //Stting the value of array index J to original value of array index I
                        Astronomical_Processing[j] = temp;
                    }
                }
            }
            DisplayTasks();
            ToolStripStatus.Text = "The data has been sorted.";
        }
        #endregion

        #region Binary Search
        //S1: PR The search method must be coded using the binary search algorithm
        //S1: PR A single text box is provided for the search input
        //S1: CR The client can use a text box input to search the array
        //S1: CR There are buttons that can search and sort the data
        private void ButtonSearch_Click(object sender, EventArgs e)

        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                int target = int.Parse(TextBox.Text);
                int min = 0;
                int max = nextEmptySpot - 1;
                int mid = 0;
                bool found = false;

                while (min <= max)
                {
                    //Declaring the middle point of the array
                    mid = (min + max) / 2;
                    //If the target is found at the middle point, the loop ends 
                    if (target == Astronomical_Processing[mid])
                    {
                        found = true;
                        break;
                        //If the target is not found at the first mid point, the program will 
                        //determine if the target is higher or lower than the oriignal mid point and define
                        //a new mid point based on this result. This process will continue until either the
                        //target is located or the whole array has been searched and the target not found
                    }
                    else if (target < Astronomical_Processing[mid])
                    {
                        max = mid - 1;
                    }
                    else
                    {
                        min = mid + 1;
                    }

                }
                //S1: PR The program must generate a message if the search is successful
                //If the target is located, the program will display a message to confirm 
                //and highlight the result in the listbox
                if (found)
                {
                    ToolStripStatus.Text = "Item found at element [" + mid + "]";
                    TextBox.Clear();
                    ListBox.SetSelected(mid, true);
                }
                //S1: PR The program must generate an error message if the search is not successful
                //If the target is not found, the program will display a message to confirm this and
                //prompt the user to ensure that the data is sorted. The search result will not be 
                //if the data is not first sorted
                else
                {
                    MessageBox.Show("Item not found. " +
                        "For accurate results, please ensure that the data is sorted.");
                    ToolStripStatus.Text = "";
                    TextBox.Clear();
                }
                //If the target is not entered in the text box, the program will display a message to prompt
                //the user to input a search term.
            }
            else
            {
                MessageBox.Show("Please enter a whole number to search. ");
                ToolStripStatus.Text = "";
                TextBox.Clear();
            }

        }
        #endregion

        #region Utilities
        //S1: PR The array is filled with random integers to simulate the data stream (numbers between 10 and 99)
        //The 'test' button assigns 24 random numbers to the array and displays them in the
        //listbox
        private void ButtonTest_Click(object sender, EventArgs e)
        {
            Random randNum = new Random();
            nextEmptySpot = 0;

            for (int i = 0; i < 24; i++)
            {
                Astronomical_Processing[nextEmptySpot] = randNum.Next(10, 100);
                nextEmptySpot++;
            }
            DisplayTasks();
            ToolStripStatus.Text = "Random test data displayed.";
        }
        #endregion

        #region Sequential Search
        //S2: CR A button to initiate a sequential search
        //Sequential Search button
        private void ButtonSequentialSearch_Click(object sender, EventArgs e)
        {
            // If the textbox is NOT null or empty then the search will be initiated 
            //once the button has been clicked.
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                //Declaring local variables
                int target = int.Parse(TextBox.Text);
                bool found = false;
                //S2: PR The sequential search method must be coded using a single FOR loop and one IF condition
                //Declaring integer I as 0 - this is the index value in the array that the sort will commence from
                //When I is less than the length of the array, I will increases by 1
                for (int i = 0; i < nextEmptySpot; i++)
                {
                    //If I equals the target you are searching for it will highlight the target 
                    //and will set the boolean value to true
                    if (Astronomical_Processing[i].Equals(target))
                    {
                        ListBox.SelectedIndex = i;
                        TextBox.Clear();
                        TextBox.Focus();
                        found = true;
                        break;
                    }
                }
                //S2: PR The program must generate a message if the search is successful
                //If the boolean, found, is true, then the status strip will display Found.
                if (found)
                    ToolStripStatus.Text = "Found";
                //S2: PR The program must generate an error message if the search is not successful
                //Else the boolean will display false and the status strip will display Not Found
                else
                    ToolStripStatus.Text = "Not Found";
            }
            //S2: PR The program must generate an error message if the text box is empty
            //If there is no data in the text box a message box will display and ask for you to input data in the text box
            else
            {
                MessageBox.Show("Item not found, please make sure there is data in the text box.");
                ToolStripStatus.Text = "";
                TextBox.Clear();
            }

        }
        #endregion

        #region Maths Functions
        //S2: CR A button to calculate the mode
        //This button calculates the mode

        private void ButtonMode_Click(object sender, EventArgs e)
        {
            //declearing variables 
            int element;
            int frequency = 1;
            int mode = 0;
            int counter;
            //i is set at 0. As long as i is less than the length of the array, it will increase by 1
            for (int i = 0; i < Astronomical_Processing.Length; i++)
            {
                //declearing variables
                //counter set to 0
                counter = 0;
                //element set i in the Astronomical_Processing array
                element = Astronomical_Processing[i];
                //j is set at 0. As long as j is less than the length of the array, it will increase by 1
                for (int j = 0; j < Astronomical_Processing.Length; j++)
                {
                    //if the element is the same as j in astronomical processing, increase the counter by 1
                    if (element == Astronomical_Processing[j])
                    {
                        counter++;
                    }
                }
                if (counter >= frequency)
                {
                    frequency = counter;
                    mode = element;
                }
            }
            //S2: PR The mathematic calculations will display in separate text boxes 
            //formatted to two decimal places as appropriate
            //print mode and frequency in TextBoxMode
            TextBoxMode.Text = mode.ToString() + ", (" + frequency.ToString() + ")";
            //print, in the status strip, that the mode has been found
            ToolStripStatus.Text = "The Mode has been found!";
        }

        //S2: CR A button to calculate the Mid-Extreme
        //This button calculates the Mid-Extreme
        private void ButtonMidExtreme_Click(object sender, EventArgs e)
        {
            //declaring variables 
            int maximumValue = 0;
            int minimumValue = 100;
            double midValue;
            //These varables mind the max and min in the array
            maximumValue = FindMax(Astronomical_Processing);
            minimumValue = FindMin(Astronomical_Processing);
            midValue = FindMidExtreme(Astronomical_Processing);
            //S2: PR The mathematic calculations will display in separate text boxes 
            //formatted to two decimal places as appropriate
            //prints the midValue in the TextBoxMidExtreme
            TextBoxMidExtreme.Text = midValue.ToString();

            //This method finds the Mid-Extreme
            double FindMidExtreme(int[] Astronomical_Processing)
            {
                //i has the assigned value of max value plus the min value divided by 2
                double i = (double)(maximumValue + minimumValue) / 2;
                return i;
            }
            //print on the status strip that they Mid-Extreme has been found
            ToolStripStatus.Text = "The Mid-Extreme has been found!";
        }

        //S2: CR A button to calculate the Average
        //This button calculates the Average
        private void ButtonAverage_Click(object sender, EventArgs e)
        {
            //Declaring variables 
            double sum = 0;
            double avg = 0;
            avg = Average(Astronomical_Processing);

            //This method finds the average of the elements in the array
            double Average(int[] Astronomical_Processing)
            {
                //i is set at 0. As long as i is less than the length of the array, it will increase by 1
                for (int i = 0; i < Astronomical_Processing.Length; i++)
                {
                    //This finds the sum of all the content in the array
                    sum += Astronomical_Processing[i];
                    //This divides the sum by the length of the array
                    avg = (double)(sum / Astronomical_Processing.Length);
                }
                //S2: PR The mathematic calculations will display in separate text boxes 
                //formatted to two decimal places as appropriate
                //This prints the average into the TextBoxAverage to two decimal places
                TextBoxAverage.Text = avg.ToString("n2");
                return avg;
            }
            //prints "The average has been found" on the status strip
            ToolStripStatus.Text = "The Average has been found!";
        }
        //S2: CR A button to calculate the Range
        //This button calculates the Range
        private void ButtonRange_Click(object sender, EventArgs e)
        {
            //Decalring variables
            int maximumValue = 0;
            int minimumValue = 100;
            double range;
            //Finds the max and min in the array
            maximumValue = FindMax(Astronomical_Processing);
            minimumValue = FindMin(Astronomical_Processing);
            //calls the find range method
            range = FindRange(Astronomical_Processing);
            //S2: PR The mathematic calculations will display in separate text boxes 
            //formatted to two decimal places as appropriate
            //Prints the range in the TextBoxRange text box
            TextBoxRange.Text = range.ToString();

            //This is the find range method
            double FindRange(int[] Astronomical_Processing)
            {
                //subtracts the minimum value from the maximum value
                double i = (double)(maximumValue - minimumValue);
                return i;
            }
            //prints the that the range has been found in the status strip
            ToolStripStatus.Text = "The Range has been found!";
        }
        

        //A method to find the maximum number in the array
        int FindMax(int[] Astronomical_Processing)
        {
            //decalring variables
            int max1 = 0;
            //x is set at 0. As long as x is less than the length of the array, it will increase by 1
            for (int x = 0; x < Astronomical_Processing.Length; x++)
            {
                //if x in the Astronomical_Processing array in less than or equal to the max
                if (Astronomical_Processing[x] >= max1)
                    //max is equal x in Astronomical_Processing
                    max1 = Astronomical_Processing[x];
            }
            return max1;

        }

        //A method to find the minimum number in an array
        int FindMin(int[] Astronomical_Processing)
        {
            //decalring variables
            int min1 = 100;
            //i is set at 0. As long as i is less than the length of the array, it will increase by 1
            for (int x = 0; x < Astronomical_Processing.Length; x++)
            {
                //if x in the Astronomical_Processing array in less than or equal to the min
                if (Astronomical_Processing[x] <= min1)
                    //min is equal x in Astronomical_Processing
                    min1 = Astronomical_Processing[x];
            }
            return min1;
        }
        #endregion

        #region Character Preventaion
        //This prevents unwanted characters being entered into the textbox. It will only let inegers be inputed.
        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }        

        #endregion

        #region Display Listbox Item in Textbox
        //When you select an item in a listbox it will display in the textbox so that you can edit it. 
        private void ListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextBox.Text = ListBox.SelectedItem.ToString();
        }
        #endregion
    }
}